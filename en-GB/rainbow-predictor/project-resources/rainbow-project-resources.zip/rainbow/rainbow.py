#!/bin/python3

from sense_hat import SenseHat

sense = SenseHat()
sense.clear()

