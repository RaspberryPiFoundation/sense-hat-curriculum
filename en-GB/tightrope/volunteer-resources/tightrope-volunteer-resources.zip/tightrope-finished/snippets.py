path = [
  y,y,y,x,x,x,x,x,
  x,x,y,x,x,x,x,x,
  x,x,x,x,x,x,x,x,
  x,x,x,x,x,x,x,x,
  x,x,x,x,x,x,x,x,
  x,x,x,x,x,x,x,x,
  x,x,x,x,x,x,x,x,
  x,x,x,x,x,x,x,x
]
