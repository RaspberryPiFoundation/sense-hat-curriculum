#!/bin/python3

from sense_hat import SenseHat
from time import sleep

sense = SenseHat()



