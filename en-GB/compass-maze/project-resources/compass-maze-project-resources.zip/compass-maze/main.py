#!/bin/python3

from sense_hat import *

sense = SenseHat()
sense.clear()



